from tox._cmdline import main

main()
